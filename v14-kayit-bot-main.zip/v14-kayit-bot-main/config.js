module.exports = {
    token: "MTAxNjA1MjI5OTkzMzcwMDIxNg.Gq6qF-.e4GafbLN9pGVhJ1Y_Hcxh-UePD3EfFQyw_FFC8", 
    prefix: "!"
}

//Lrows